このFigma Makeファイルには、[shadcn/ui](https://ui.shadcn.com/)([MITライセンス](https://github.com/shadcn-ui/ui/blob/main/LICENSE.md)の下で使用)からのコンポーネントが含まれています。

このFigma Makeファイルには、[Unsplash](https://unsplash.com)からの写真が含まれており、[ライセンス](https://unsplash.com/license)の下で使用されています。