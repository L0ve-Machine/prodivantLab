
  # Product Page Creation

  This is a code bundle for Product Page Creation. The original project is available at https://www.figma.com/design/fH2KNPWDHYFm7uLd1CD30e/Product-Page-Creation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  